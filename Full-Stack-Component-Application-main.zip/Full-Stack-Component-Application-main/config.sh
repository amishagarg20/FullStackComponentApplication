# config.sh
CONFIG_FILE='/home/ec2-user/aws/config.sh'

GITHUB_USERNAME='amishagarg20'
REPOSITORY_NAME='Full-Stack-Component-Application'
GITHUB_PASSWORD='Amisha@828'
GITHUB_TOKEN='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'
Email='amishagarg828@gmail.com'
